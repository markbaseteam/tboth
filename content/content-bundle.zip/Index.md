---
publish: true
tags: [type/data]
aliases: [BOTH]
---

# Index

```dataview
TABLE file.mtime AS Date
FROM "both"
SORT file.path
```
