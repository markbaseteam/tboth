---
publish: true
tags: []
aliases: []
---

# Bottom of the Hole

> A Traveller science-fiction roleplaying game alternative background

## Concept

- While expanding into the stars a wormhole is discovered.
- The other side of the wormhole is a region dense with resources and habitable systems.
- After a few generations of migration into the region, the wormhole closes.

## Next

- TBD
